
<?php include('admin/config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon"href="<?php echo SITEURL; ?>images/favicon.ico">
	<title>ORDER FOOD</title>
	<link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="http://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
	
</head>
<body>
	
<header class="navbar">
	<nav id="site-top-var" class="navbar-menu navbar-fixed-top animated fadeInUpBig">
		<div class="container">
        <!-- logo -->
		<div class="logo">
		<a href="<?php echo SITEURL;?>" title="Logo">
			<img src="images/logo.png" alt="logo order food" width="50px" height="70px" class="img-responsive">
</a>
        </div>

		<!-- menu chính về tab bar -->
          <div class="menu text-right">
		  <ul>
                    <li>
                        <a class="hvr-underline-from-center" href="<?php echo SITEURL; ?>">Trang chủ</a>
                    </li>
                    <li>
                        <a class="hvr-underline-from-center" href="<?php echo SITEURL; ?>categories.php">Danh mục</a>
                    </li>
                    <li>
                        <a class="hvr-underline-from-center" href="<?php echo SITEURL; ?>foods.php">Mặt hàng</a>
                    </li>
                    <li>
                        <a class="hvr-underline-from-center" href="<?php echo SITEURL; ?>order.php">Gọi món</a>
                    </li>
                    <li>
                        <a class="hvr-underline-from-center" href="<?php echo SITEURL; ?>contact.php">Liên hệ</a>
                    </li>
                    <li>
                        <a class="hvr-underline-from-center" href="<?php echo SITEURL; ?>login.php">Đăng nhập</a>
                    </li>
					
					<!-- <i class="fa fa-registered" aria-hidden="true"></i> -->
                    <li>
						 <a id="shopping-cart" class="shopping-cart">
					<?php 
								if(isset($_COOKIE["shopping_cart"]))
								{
									$food_count = 0;
									$cookie_data = stripslashes($_COOKIE['shopping_cart']);
									$cart_data = json_decode($cookie_data, true);
									foreach($cart_data as $keys => $values)
									{
										$food_count++;
									}
									if($food_count<=0){
										$url= (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
										header("location:cart_core.php?action=clear&url=$url");
									}
								}
							?>


<i class="fa fa-cart-arrow-down" aria-hidden="true"></i> <?php if(isset($_COOKIE["shopping_cart"]) && $food_count>0){echo "<span class='notify'>$food_count</span>";} ?>
						 </a>
						   <div id="cart-content" class="cart-content">
								<h3 class="text-center">Giỏ hàng</h3>
								<table class="cart-table" border="0">
									<tr>
										<th>Món ăn</th>
										<th>Tên món ăn</th>
										<th>Giá</th>
										<th>Số lượng</th>
										<th>Tổng</th>
										<th>Hoạt động</th>
									</tr>
								
									<?php
										if(isset($_COOKIE["shopping_cart"]))
										{
											$total = 0;
											$current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
											$cookie_data = stripslashes($_COOKIE['shopping_cart']);
											$cart_data = json_decode($cookie_data, true);
											foreach($cart_data as $keys => $values)
											{
										?>
											<tr>
												<td>
													<img src="images/food/<?php echo $values["item_img"]; ?>" alt="" />
												</td>
												<td><?php echo $values["item_name"]; ?></td>
												<td><?php echo $values["item_price"]; ?></td>
												<td><?php echo $values["item_quantity"]; ?></td>
												<td><?php echo number_format($values["item_quantity"] * $values["item_price"],  0,'.', ' ');?></td>
												<td><a class="btn btn-danger" href="cart_core.php?action=delete&id=<?php echo $values["item_id"]; ?>&food=<?php echo $values["item_name"]; ?>&url=<?php echo $current_url; ?>">&times;</a></td>
												
											</tr>
										<?php	
												$total = $total + ($values["item_quantity"] * $values["item_price"]);
											}
										?>
											<tr>
												<th colspan="4">Tổng</th>
												<th><?php echo number_format($total, 0,'.', ' '); ?></th>
												<th></th>
											</tr>
										<?php

										
		
										}
										else
										{
											echo '
											<tr>
												<td colspan="6" align="center">Không có mặt hàng trong giỏ hàng</td>
											</tr>
											';
										}
										?>
										
								</table> 
								<a href="<?php echo SITEURL; ?>order.php" class="btn btn-primary">Xác nhận đơn hàng</a>
							</div>
                    </li>
                </ul>
            </div>
			<div class="clearfix"></div>
			</div>
		</nav>  
    </header>