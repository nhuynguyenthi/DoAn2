<?php ob_start();
include('header.php'); ?>

<!-- food search  -->
<section class="contact">
        <div class="container">
            
            <h2 class="text-center">LiÊN HỆ</h2>
			<div class="heading-border"></div>

            <?php
				if(isset($_SESSION['contact'])){
					echo $_SESSION['contact'];
					unset($_SESSION['contact']);
				}
			?>

            <form action="" method="POST" class="contact-form">
               
               <fieldset>
                   <legend>LIÊN HỆ VỚI CHÚNG TÔI</legend>
                   <div class="contact-label">Họ Và Tên</div>
                   <input type="text" name="name" placeholder="Nhập tên của bạn" class="input-responsive" required>
                   
                   <div class="contact-label">Email</div>
                   <input type="email" name="email" placeholder="Nhập email của bạn" class="input-responsive" required>

                   <div class="contact-label">SĐT</div>
                   <input type="tel" name="phone" placeholder="Nhập số điện thoại của bạn " class="input-responsive" required>

                   <div class="contact-label">Tiêu đề</div>
                   <input type="text" name="subject" placeholder="Nhập tiêu đề" class="input-responsive" required>

                   <div class="contact-label">Nhắn nội dung</div>
                   <textarea name="message" rows="5" placeholder="Nhập tin nhắn của bạn" class="input-responsive" required></textarea>

                   <input type="submit" name="submit" value="Gửi" class="btn btn-primary">
               </fieldset>

           </form>   
           
           
           <?php
				if(isset($_REQUEST['submit'])){
					$name = mysqli_real_escape_string($conn, $_REQUEST['name']);
					$email = mysqli_real_escape_string($conn, $_REQUEST['email']);
					$phone = mysqli_real_escape_string($conn, $_REQUEST['phone']);
					$subject = mysqli_real_escape_string($conn, $_REQUEST['subject']);
					$message = mysqli_real_escape_string($conn, $_REQUEST['message']);
					$sql = "INSERT INTO contact SET
						name = '$name',
						email = '$email',
						phone = '$phone',
						subject = '$subject',
						message = '$message',
						status = 'Unread'
					";
					$res = mysqli_query($conn, $sql);
					if($res ==  true){
						$_SESSION['contact'] = "<div class='success text-center'>Tin nhắn đã gửi thành công.</div>";
						header('location:'.SITEURL.'contact.php');
					}
					else{
						$_SESSION['contact'] = "<div class='error text-center'>Tin nhắn gửi thất bại.</div>";
						header('location:'.SITEURL.'contact.php');
					}
					
					
				}
			?>

           </div>
    </section>

    	<!-- Map Start Here -->
	<section class="Map">
		<h2 class="text-center">Địa chỉ của chúng tôi</h2>
		<div class="heading-border"></div>
		<div class="mapouter">
			<div class="gmap_canvas">
            <iframe id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31360.071508853973!2d106.55147491488219!3d10.73379361042099!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752d96d6186081%3A0x54a4ef4abc0b6ac0!2zTmjDoCBow6BuZyBUcnVuZyBIb2E!5e0!3m2!1svi!2s!4v1667615552889!5m2!1svi!2s" frameborder="0" marginheight="0" marginwidth="0" ></iframe>
			</div>
		</div>
	</section>

    <?php include('footer.php');
    ob_flush();
    ?>