<?php 
	include('header.php'); 
?>
    <!-- CAtegories Section Starts Here -->
    <section class="categories">
        <div class="container">
            <h2 class="text-center">Khám phá sản phẩm</h2>
			<div class="heading-border"></div>

            <?php 
				$sql = "SELECT * FROM category WHERE active='có' ORDER BY id DESC";
				$res = mysqli_query($conn, $sql);
				if($res == true){
					$count = mysqli_num_rows($res);
					if($count>0){
						while($rows = mysqli_fetch_assoc($res)){
							$id = $rows['id'];
							$title = $rows['title'];
							$image = $rows['image'];
							?>
							<a href="<?php echo SITEURL; ?>category-foods.php?category_id=<?php echo $id ?>">
								<div class="box-3 float-container">
									<?php 
										if($image != ""){
										?>
										<img src="<?php echo SITEURL; ?>images/category/<?php echo $image; ?>" alt=""  class="img-responsive img-curve" />
										<?php
										}
										else{
											echo "<div class='error'>Hình ảnh chưa có.</div>";
										}
									?>
									

									<h3 class="float-text text-white"><?php echo $title ?></h3>
									
								</div>
							</a>
							<?php
						}
					}
					else{
						echo "<div class='error'>Loại hàng chưa có.</div>";
					}
				}
			?>

            <div class="clearfix"></div>
        </div>
    </section>



	
	<?php include('in_footer.php');?>
    <!-- Categories Section Ends Here -->

<?php 
	include('footer.php'); 
?>
