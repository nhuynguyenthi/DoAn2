<?php include('header.php'); ?>
<?php

        if(isset($_REQUEST['submit'])){
            $email = mysqli_real_escape_string($conn, $_REQUEST['email']);
            $password = $_REQUEST['password'];
			
			$sql = "SELECT * FROM admin WHERE email='$email' AND password='$password'";
			$res = mysqli_query($conn, $sql);
			$count = mysqli_num_rows($res);
			if($count == 1){
				while($rows = mysqli_fetch_assoc($res)){
					$role = $rows['role'];
				}
				if($role=="Admin"){
					$_SESSION['login_true'] = "<div class='success'>Quản trị viên đăng nhập thành công</div>";
					$_SESSION['admin'] = $email;
					?>
						<script><?php echo ("location.href = '".SITEURL."admin/';");?></script>
					<?php
				}
				else if($role=="Manager"){
					$_SESSION['login_true'] = "<div class='success'>Quản lý đăng nhập thành công.</div>";
					$_SESSION['manager'] = $email;
					?>
						<script><?php echo ("location.href = '".SITEURL."admin/';");?></script>
					<?php
				}
			}
			else{
				$_SESSION['login_false'] = "<div class='error'>Email hoặc mật khẩu không đúng.</div>";
				?>
					<script><?php echo ("location.href = ".SITEURL."login.php");?></script>
				<?php
			}
        }
    ?>

    <!-- CAtegories Section Starts Here -->
    <section class="login">
        <div class="container" >
            <h2 class="text-center">ĐĂNG NHẬP</h2>
			<div class="heading-border"></div>
			
			<?php 
				if(isset($_SESSION['login_false'])){
					echo $_SESSION['login_false'];
					unset($_SESSION['login_false']);
				}
				if(isset($_SESSION['unauthorized'])){
					echo $_SESSION['unauthorized'];
					unset($_SESSION['unauthorized']);
				}
			?>
			

			
			<br />
            
			<?php
				if( isset($_SESSION['manager'])==false && isset($_SESSION['admin'])==false ){
					?>
					<form action="" method="POST">
						<table class="tbl-30 login-tbl-35 login-form">

							<tr>
								<td>Email:</td>
								<td>
									<input type="email" name="email" placeholder="Nhập email" required>
								</td>
							</tr>
							<tr>
								<td>Mật Khẩu:</td>
								<td>
									<input type="password" name="password" placeholder="Nhập mật khẩu" required>
								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<input type="submit" name="submit" value="Đăng nhập" class="btn-secondary">
								</td>
							</tr>

						</table>
					</form>
					<?php
				}
				else{
					?>
					<p class="success">Bạn đã đăng nhập.</p>
					<br />
					<p class="text-center">Đến với <a href="<?php echo SITEURL; ?>/admin" class="btn-primary">Bảng kiểm kê</a></p>
					<br>
	                <p class="text-center mt-5"><a href="<?php echo SITEURL; ?>/admin/logout.php" class="btn-danger">Thoát</a></p>
					
					<?php
				}
			?>
			
            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->

    <?php include('footer.php'); ?>
 









