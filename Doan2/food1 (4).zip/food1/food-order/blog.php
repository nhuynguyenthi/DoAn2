<?php
include('header.php');
?>
<style>
    .archive_content .single_title{
        margin: 0 0 10px 0!important;
        text-align: center;
        display: block;
        width: 100%;
        float: left;
        /* margin: 30px 0 0; */
        font-size: 20px;
        font-weight: 600;
    }

    h3{
        color:green;
    }

    p,img{
        margin-left:200px;
        margin-right:200px; 
    }
</style>
<section class="blog" style="padding:50px">
<!-- Pizza kiểu Đức -->
    <div class="archive_content">
        <h3 class="single_title">PIZZA PHÔ MAI XÚC XÍCH THƯỢNG HẠNG KIỂU ĐỨC</h3>
    </div>
    <div class="single_content">
        <p>
            <span style="font-weight:400;box-sizing: border-box;line-height: 1.5em; text-align: middle ;">
                Sự hấp dẫn từ những món ăn "đường phố" luôn khiến các thực khách không thể chối từ. 
                Vậy nên hôm nay TBZ STORE xin được gửi tới bạn một món ăn Pizza :"Pizza nóng" ở Đức <mark?> hãy cùng theo dõi bài viết nhé:</mark></span>
        </p><br>

        <p>
            <span style="font-weight:400;"> Pizza kiểu Đức là một loại Pizza được pha trộn với nhiều phong cách và các loại topping khác nhau.
                Một trong những điều thú vị nhất khi đi du lịch chính là việc thưởng thức ẩm thực đường phố, và món ăn đường phố nhất thiết du khách phải nếm khi đến Đức là Pizza.</span>
        </p><br>

        <p>
            <img src="images/pizza-blog1.jpg" alt="" width="500" height="300"; >
        </p><br>

        <p>
            <b>Hành trình ra đời của bánh Pizza</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Chiếc bánh pizza hiện đại ra đời năm 1889 khi hoàng hậu Margherita Teresa Giovanni - vợ vua Umberto I của Italy đến thăm Napoli.
                Chủ quán rượu Pietro Il Pizzaiolo - ông Raffaele Esposito được yêu cầu làm một món đặc biệt để đón tiếp. 
                Ông đã làm một chiếc bánh pizza với cà chua, phô mai mozzarella và húng quế.</span>
        </p><br>

        <p>
            <span>Raffaele Esposito đặt tên cho chiếc bánh pizza này là Margherita. Sau đó, người Italy ở các nơi nghĩ ra 
                thêm nhiều loại nhân và tạo nên các món bánh pizza mang nét đặc sắc của từng vùng.
                Tuy nhiên, bánh Margherita vẫn được xem là loại pizza "chính thống cơ bản".</span>
        </p><br>

        <p>
            <span>Sau này khi nền ẩm thực thế giới tôn vinh bánh pizza như một phần tinh hoa của ẩm thực nhân loại, 
                món ăn này phổ biến khắp năm châu và được biến tấu cho phù hợp với khẩu vị người dân các quốc gia. 
                Người Thái Lan sáng tạo thêm kiểu pizza tom yum (tôm chua cay). Người Ấn Độ làm pizza với thịt gà cà ri, người Thổ Nhĩ Kỳ dùng thịt bằm, ôliu đỏ và hành tây. 
                Người Đức dùng các loại xúc xích làm nhân bánh...</span>
        </p><br>

        <p>
            <span>Bánh pizza theo các đoàn người Italy di cư sang châu Mỹ từ đầu thế kỷ 20. Năm 1905, Gennaro Lombardi - một người Mỹ gốc Italy 
                mở cửa hàng bánh pizza phong cách Mỹ đầu tiên ở New York. Tại đất nước này, pizza trở thành một món ăn nhanh được giao đến tận nhà. 
                Pizza trở thành fastfood từ đó và phong cách này lan rộng trên toàn thế giới nhất sau năm 1945.</span>
        </p><br>

        <p>
            <b>Tận hưởng những chiếc bánh Pizza thơm ngon với nét đặc trưng riêng.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Hãy cùng đến TBZ STORE để trải nghiệm những món mới với nhiều ưu đãi hấp dẫn. Chúng tôi luôn
                mong muốn gửi đến bạn những bữa ăn chất lượng với giá cả hợp lý nhất.</span>
        </p><br>

        <p>
            <span style="font-weight:400;">Pizza với giá hợp lý, phù hợp với mọi lứa tuổi về giá cả cũng như là chất lượng.
                Tiên phong với tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</span>
        </p>
        <br>
        <p>
            <b>TBZ STORE với bốn Tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Pizza TBZ STORE nghĩ rằng để giúp cho việc phục vụ ngày một tốt hơn. Khách hàng đặt Pizza
                chỉ cần lên website đặt món và xác nhận đặt món thì nhân viên và đội ngũ sẽ hỗ trợ và phục vụ
                nhiệt tình cho khách hàng chuẩn với dịch vụ 5 sao.</span>
        </p>

        <p>
            <span style="font-weight:400; text-align:center; color:green;">===========PIZZA TBZ STORE============</span>
        </p><br><br>

<!-- Pizza kiểu Việt -->
    <div class="archive_content">
        <h3 class="single_title" id="pizzaViet">PIZZA THƯỢNG HẠNG KIỂU VIỆT</h3>
    </div>
    <div class="single_content">
        <p>
            <span style="font-weight:400;box-sizing: border-box;line-height: 1.5em; text-align: middle ;">
                Sự hấp dẫn từ những món ăn "đường phố" luôn khiến các thực khách không thể chối từ. 
                Vậy nên hôm nay TBZ STORE xin được gửi tới bạn một món ăn Pizza, <mark?> hãy cùng theo dõi bài viết nhé:</mark></span>
        </p><br>

        <p>
            <span style="font-weight:400;">
                Sau khi được tham khảo và học hỏi cách làm cũng như hương vị của các loại Pizza nước ngoài, 
                thì Pizza kiểu Việt là một loại Pizza được làm ra với phong cách hoàn toàn mới với nhiều topping và phù hợp với khẩu vị của người Việt hơn.
                Một trong những điều thú vị nhất khi đi du lịch chính là việc thưởng thức ẩm thực đường phố, 
                và du khách khi đến nơi đây không thể không thử thử món Pizza kiểu Việt với phòng cách hoàn toàn mới và độc đáo.</span>
        </p><br>

        <p>
            <img src="images/pizza-blog2.jpg" alt="" width="500" height="300"; >
        </p><br>

        <p>
            <b>Hành trình ra đời của bánh Pizza</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Chiếc bánh pizza hiện đại ra đời năm 1889 khi hoàng hậu Margherita Teresa Giovanni - vợ vua Umberto I của Italy đến thăm Napoli.
                Chủ quán rượu Pietro Il Pizzaiolo - ông Raffaele Esposito được yêu cầu làm một món đặc biệt để đón tiếp. 
                Ông đã làm một chiếc bánh pizza với cà chua, phô mai mozzarella và húng quế.</span>
        </p><br>

        <p>
            <span>Raffaele Esposito đặt tên cho chiếc bánh pizza này là Margherita. Sau đó, người Italy ở các nơi nghĩ ra 
                thêm nhiều loại nhân và tạo nên các món bánh pizza mang nét đặc sắc của từng vùng.
                Tuy nhiên, bánh Margherita vẫn được xem là loại pizza "chính thống cơ bản".</span>
        </p><br>

        <p>
            <span>Sau này khi nền ẩm thực thế giới tôn vinh bánh pizza như một phần tinh hoa của ẩm thực nhân loại, 
                món ăn này phổ biến khắp năm châu và được biến tấu cho phù hợp với khẩu vị người dân các quốc gia. 
                Người Thái Lan sáng tạo thêm kiểu pizza tom yum (tôm chua cay). Người Ấn Độ làm pizza với thịt gà cà ri, người Thổ Nhĩ Kỳ dùng thịt bằm, ôliu đỏ và hành tây. 
                Người Đức dùng các loại xúc xích làm nhân bánh.
                Người Việt dùng sốt cà chua được nướng chung vwois mực và tôm địa phương tạo thành món pizza đặc biệt phù hợp với khẩu vị người Việt.</span>
        </p><br>

        <p>
            <span>Bánh pizza theo các đoàn người Italy di cư sang châu Mỹ từ đầu thế kỷ 20. Năm 1905, Gennaro Lombardi, 
                một người Mỹ gốc Italy mở cửa hàng bánh pizza phong cách Mỹ đầu tiên ở New York. 
                Tại đất nước này, pizza trở thành một món ăn nhanh được giao đến tận nhà. 
                Pizza trở thành fastfood từ đó và phong cách này lan rộng trên toàn thế giới nhất sau năm 1945.</span>
        </p><br>

        <p>
            <b>Tận hưởng những chiếc bánh Pizza thơm ngon với nét đặc trưng riêng.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Hãy cùng đến TBZ STORE để trải nghiệm những món mới với nhiều ưu đãi hấp dẫn. Chúng tôi luôn
                mong muốn gửi đến bạn những bữa ăn chất lượng với giá cả hợp lý nhất.</span>
        </p><br>

        <p>
            <span style="font-weight:400;">Pizza với giá hợp lý, phù hợp với mọi lứa tuổi về giá cả cũng như là chất lượng.
                Tiên phong với tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</span>
        </p>
        <br>
        <p>
            <b>TBZ STORE với bốn Tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">TBZ STORE nghĩ rằng để giúp cho việc phục vụ ngày một tốt hơn. Khách hàng đặt Pizza 
                chỉ cần lên website đặt món và xác nhận đặt món thì nhân viên và đội ngũ sẽ hỗ trợ và phục vụ
                nhiệt tình cho khách hàng chuẩn với dịch vụ 5 sao.</span>
        </p>

        <p>
            <span style="font-weight:400;text-align:center;color:green;">===========PIZZA TBZ STORE============</span>
        </p>

<!-- hamburger kiểu Mĩ -->
    <div class="archive_content">
        <h3 class="single_title" id="hamburgerMi">HAMBURGER KIỂU MĨ</h3>
    </div>
    <div class="single_content">
        <p>
            <span style="font-weight:400;box-sizing: border-box;line-height: 1.5em; text-align: middle ;">
                Sự hấp dẫn từ những món ăn "đường phố" luôn khiến các thực khách không thể chối từ. 
                Vậy nên hôm nay TBZ STORE xin được gửi tới bạn một món ăn Hamburger, <mark?> hãy cùng theo dõi bài viết nhé:</mark></span>
        </p><br>

        <p>
            <span style="font-weight:400;">
                Hamburger kiểu Mĩ được làm và kết hợp với khẩu vị đặc trưng như là thịt hay hoặc thịt bò,
                kèm thêm một số loại rau như: salad, cà chua và một số gia vị khác. Với sự kết hợp tinh hoa, đầy đủ hương vị đặc sắc
                cùng với mùi thơm của bánh mỳ nóng giòn và đầy đủ các loại topping đã tạo nên những chiếc bánh Hamburger hảo hạn thơm ngon từ đầu bếp.</span>
        </p><br>

        <p>
            <img src="images/hamburger-blog3.jpg" alt="" width="500" height="300"; >
        </p><br>

        <p>
            <b>Hành trình ra đời của bánh Hamburger</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Một số người cho rằng những người dân du mục Tatars từ khu vực Trung Á đã mang món bánh mì kẹp thịt
            đến nước Đức. Họ là nhừng kỵ sĩ song nay đây mai đó trên lưng ngựa, di chyển liên tục và không có thời gian để dừng lại ăn uống.
            Họ thường ăn thịt sống và cất dưới yên ngựa trong quá trình di chuyển. Qua thời gian cưỡi ngựa kéo dài,
            thịt trở nên mềm hơn và sức nóng từ ngựa tỏa ra sẽ làm chín thịt. Khi đến vùng cảng Hamburg của Đức, họ đã giới thiệu
            món ăn này cho người dân địa phương.</span>
        </p><br>

        <p>
            <span>Người Đức chế biến thêm muối, tiêu, tỏi và hành tây vào thịt rồi tạo thành những miếng chả, sao đó chiên hoặc nướng
                chúng để tạo ra cách ăn độc đáo. Những người Đức di cư đến Mỹ sau đó mang theo mon sbit tết Hamburg này và nó 
                bắt đầu xuất hiện trong thực đơn của các nhà hàng Mỹ vào những năm 1880.</span>
        </p><br>

        <p>
            <span>Ngày nay có rất nhiều biến thể khác nhau của hamburger được sáng tạo ở khắp mọi nơi trên thế giới.
                Bạn có thể tìm thấy hamburger với cá, thịt chay và thịt gà chứ không phải là thịt bò như truyền thống.</span>
        </p><br>

        <p>
            <span>Hamburger là một trong những món ăn phổ biến nhất hiện nay của người Mỹ, là một phần thiết yếu trong những dịp lễ
                như Quốc Khánh. Món này không chỉ rẻ mà còn rất dễ ăn, rất phù hợp cho những người hay di chuyển.
                Cũng như món Pizza, Hamburger cũng trở thành fastfood và phong cách này lan rộng trên toàn thế giới.</span>
        </p><br>

        <p>
            <b>Tận hưởng những chiếc bánh Hamburger thơm ngon với nét đặc trưng riêng.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Hãy cùng đến TBZ STORE để trải nghiệm những món mới với nhiều ưu đãi hấp dẫn. Chúng tôi luôn
                mong muốn gửi đến bạn những bữa ăn chất lượng với giá cả hợp lý nhất.</span>
        </p><br>

        <p>
            <span style="font-weight:400;">Hamburger với giá hợp lý, phù hợp với mọi lứa tuổi về giá cả cũng như là chất lượng.
                Tiên phong với tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</span>
        </p>
        <br>
        <p>
            <b>TBZ STORE với bốn Tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">TBZ STORE nghĩ rằng để giúp cho việc phục vụ ngày một tốt hơn. Khách hàng đặt Hamburger 
                chỉ cần lên website đặt món và xác nhận đặt món thì nhân viên và đội ngũ sẽ hỗ trợ và phục vụ
                nhiệt tình cho khách hàng chuẩn với dịch vụ 5 sao.</span>
        </p>

        <p>
            <span style="font-weight:400;text-align:center;color:green;">===========HAMBURGER TBZ STORE============</span>
        </p><br><br>


        <!-- hamburger kiểu Việt -->
    <div class="archive_content">
        <h3 class="single_title" id="hamburgerViet">HAMBURGER KIỂU VIỆT</h3>
    </div>
    <div class="single_content">
        <p>
            <span style="font-weight:400;box-sizing: border-box;line-height: 1.5em; text-align: middle ;">
                Sự hấp dẫn từ những món ăn "đường phố" luôn khiến các thực khách không thể chối từ. 
                Vậy nên hôm nay TBZ STORE xin được gửi tới bạn một món ăn Hamburger, <mark?> hãy cùng theo dõi bài viết nhé:</mark></span>
        </p><br>

        <p>
            <span style="font-weight:400;">
                Hamburger kiểu Việt được chế biến từ loại bột mì thơm ngon được chọn lọc kem theo hương vị của chả quế và các
                loại thịt heo được nướng lên kèm với rau xà lách và cà chua mang đậm chất Việt, kèm theo đó là xốt phô mai
                và mayonnaise mang tới một hương vị đầy đủ chua mặn ngọt.</span>
        </p><br>

        <p>
            <img src="images/hamburger-blog4.jpg" alt="" width="500" height="300"; >
        </p><br>

        <p>
            <b>Hành trình ra đời của bánh Hamburger</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Một số người cho rằng những người dân du mục Tatars từ khu vực Trung Á đã mang món bánh mì kẹp thịt
            đến nước Đức. Họ là nhừng kỵ sĩ song nay đây mai đó trên lưng ngựa, di chyển liên tục và không có thời gian để dừng lại ăn uống.
            Họ thường ăn thịt sống và cất dưới yên ngựa trong quá trình di chuyển. Qua thời gian cưỡi ngựa kéo dài,
            thịt trở nên mềm hơn và sức nóng từ ngựa tỏa ra sẽ làm chín thịt. Khi đến vùng cảng Hamburg của Đức, họ đã giới thiệu
            món ăn này cho người dân địa phương.</span>
        </p><br>

        <p>
            <span>Người Đức chế biến thêm muối, tiêu, tỏi và hành tây vào thịt rồi tạo thành những miếng chả, sao đó chiên hoặc nướng
                chúng để tạo ra cách ăn độc đáo. Những người Đức di cư đến Mỹ sau đó mang theo mon sbit tết Hamburg này và nó 
                bắt đầu xuất hiện trong thực đơn của các nhà hàng Mỹ vào những năm 1880.</span>
        </p><br>

        <p>
            <span>Ngày nay có rất nhiều biến thể khác nhau của hamburger được sáng tạo ở khắp mọi nơi trên thế giới.
                Bạn có thể tìm thấy hamburger với cá, thịt chay và thịt gà chứ không phải là thịt bò như truyền thống.</span>
        </p><br>

        <p>
            <span>Hamburger là một trong những món ăn phổ biến nhất hiện nay của người Mỹ, là một phần thiết yếu trong những dịp lễ
                như Quốc Khánh. Món này không chỉ rẻ mà còn rất dễ ăn, rất phù hợp cho những người hay di chuyển.
                Cũng như món Pizza, Hamburger cũng trở thành fastfood và phong cách này lan rộng trên toàn thế giới.</span>
        </p><br>

        <p>
            <b>Tận hưởng những chiếc bánh Hamburger thơm ngon với nét đặc trưng riêng.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Hãy cùng đến TBZ STORE để trải nghiệm những món mới với nhiều ưu đãi hấp dẫn. Chúng tôi luôn
                mong muốn gửi đến bạn những bữa ăn chất lượng với giá cả hợp lý nhất.</span>
        </p><br>

        <p>
            <span style="font-weight:400;">Hamburger với giá hợp lý, phù hợp với mọi lứa tuổi về giá cả cũng như là chất lượng.
                Tiên phong với tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</span>
        </p>
        <br>
        <p>
            <b>TBZ STORE với bốn Tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">TBZ STORE nghĩ rằng để giúp cho việc phục vụ ngày một tốt hơn. Khách hàng đặt Hamburger
                chỉ cần lên website đặt món và xác nhận đặt món thì nhân viên và đội ngũ sẽ hỗ trợ và phục vụ
                nhiệt tình cho khách hàng chuẩn với dịch vụ 5 sao.</span>
        </p>

        <p>
            <span style="font-weight:400;text-align:center;color:green;">===========HAMBURGER TBZ STORE============</span>
        </p><br><br>


        <!-- sandwich thịt nướng -->
    <div class="archive_content">
        <h3 class="single_title" id="sandwich">SANDWICH THỊT NƯỚNG</h3>
    </div>
    <div class="single_content">
        <p>
            <span style="font-weight:400;box-sizing: border-box;line-height: 1.5em; text-align: middle ;">
                Sự hấp dẫn từ những món ăn "đường phố" luôn khiến các thực khách không thể chối từ. 
                Vậy nên hôm nay TBZ STORE xin được gửi tới bạn một món ăn Hamburger, <mark?> hãy cùng theo dõi bài viết nhé:</mark></span>
        </p><br>

        <p>
            <span style="font-weight:400;">
                Sandwich thịt nướng mang đến 100% nguyên liệu tươi sạch từ trứng tươi và bơ, tinh bột khoai tây, rau xà lách, dưa leo,
                cà chua và hương vị thơm ngon không thể thiếu của món này đó chính là thịt nướng. Tất cả hòa quyện tại thành một sự 
                kết hợp hài hòa giữa các nguyên liệu trong món ăn mà không thể tách rời nhau.</span>
        </p><br>

        <p>
            <img src="images/sandwich-blog5.png" alt="" width="500" height="300"; >
        </p><br>

        <p>
            <b>Hành trình ra đời của bánh Sandwich</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Lần đầu tiên, chiếc bánh mì kẹp này được gọi là Sandwich vào năm 1726, nó được đặt theo 
            tên của Bá tước Sandwich đệ tứ, John Montague. Ông là một nhà quý tộc và rất ham mê chơi bài. Trong một lần chơi bài, 
            Bá tước không muốn phải dừng chơi để ăn nên đã bảo người phục vụ kẹp vài miếng thịt bò vào giữa hai lát bánh mì rồi mang
            lên cho ông. Nhờ đó, ông có thể vừa chơi vừa ăn. Những người chơi bên cạnh thấy vậy, thấy thật tiện nên cũng gọi món ăn 
            "giống như Sandwich", để họ có thể vừa cầm thẻ bào của mình, vừa ăn mà không hề sợ bẩn tay. Và thế là từ đó, lâu dần, 
            người ta gọi món bánh mì kẹp thịt là Sandwich, theo tên của vị bá tước đó. Dần dần, vào thế kỉ 19, bánh sandwich phổ biến
            ở Tây Ban Nha và Anh, khi xã hội công nghiệp phát triển, và mọi hoạt động của con người đều diễn ra rất nhanh và họ không 
            muốn dành quá nhiều thời gian cho bữa ăn. Cứ thế, món sandwich chu du đến mọi miền, và cho đến thế kỉ 20, nó đã trở thành
            món ăn nhanh nổi tiếng và phổ biến khắp nơi.</span>
        </p><br>

        <p>
            <span>Cùng tên gọi là Sandwich, nhưng ở nhiều nước, Sandwich lại có cách chế biến khác nhau, về cơ bản là khác về nhân kẹp
                giữa bánh. Đến Anh, bạn có thể thấy món sandwich quen thuộc đó là sandwich thịt xông khói. Ở Mỹ, mỗi chiếc bánh sandwich
                thường có ít nhất hai lát bánh mì.</span>
        </p><br>

        <p>
            <span>Tại Tây Ban Nha, từ bánh "sandwich" là một từ vay mượn từ tiếng Anh, thực chất nó dùng để chỉ một loại thực phẩm được
                làm bằng "sandwich". Hay ở Việt Nam, món bánh mì kẹp pa-tê, xúc xích, cùng đồ chua, gia vị... cũng có thể được gọi là 
                sandwich theo ý nghĩa bánh mì kẹp. Và trở thành một món ăn nhanh phổ biến trên toàn thế giới.</span>
        </p><br>

        <p>
            <b>Tận hưởng những chiếc bánh Sandwich thơm ngon với nét đặc trưng riêng.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">Hãy cùng đến TBZ STORE để trải nghiệm những món mới với nhiều ưu đãi hấp dẫn. Chúng tôi luôn
                mong muốn gửi đến bạn những bữa ăn chất lượng với giá cả hợp lý nhất.</span>
        </p><br>

        <p>
            <span style="font-weight:400;">Sandwich với giá hợp lý, phù hợp với mọi lứa tuổi về giá cả cũng như là chất lượng.
                Tiên phong với tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</span>
        </p>
        <br>
        <p>
            <b>TBZ STORE với bốn Tiêu chí: Chất lượng - Phục vụ - Vệ sinh - Giá cả.</b>
        </p><br>

        <p>
            <span style="font-weight:400;">TBZ STORE nghĩ rằng để giúp cho việc phục vụ ngày một tốt hơn. Khách hàng đặt Sandwich
                chỉ cần lên website đặt món và xác nhận đặt món thì nhân viên và đội ngũ sẽ hỗ trợ và phục vụ
                nhiệt tình cho khách hàng chuẩn với dịch vụ 5 sao.</span>
        </p>

        <p>
            <span style="font-weight:400;text-align:center;color:green;">===========SANDWICH TBZ STORE============</span>
        </p><br><br>
</section>
