<section class="footer">
<div class="container">
    <div class="box-3 text-center">
        <h3>Về chúng tôi</h3>
        <br>
        <p>Chuyên hamburger, sandwich, pizza 
           Chúng tôi sẽ cam kết không ngừng cải tiến
           nâng cấp chất lượng sản phẩm chất lượng dịch vụ
           cũng như cải tiến thiết bị để ngày ngày đáp ứng niềm tin yêu của quý Khách dành cho các loại bánh tại
        <mark> TBZ STORE </mark>

    </div>
    <div class="box-3 text-center">
        <h3>Liên kết nhanh</h3>
        <br>
        <div class="site-links ">
            <a href="<?php echo SITEURL; ?>login.php">Đăng nhập</a>
            <a href="<?php echo SITEURL; ?>categories.php">Danh mục</a>
            <a href="<?php echo SITEURL; ?>foods.php">Thức ăn</a>
            <a href="<?php echo SITEURL; ?>order.php">Gọi món</a>
            <a href="<?php echo SITEURL; ?>contact.php">Liên hệ</a>
           
        </div>
    </div>
    <div class="box-3 text-center">
        <h3>Theo dõi chúng tôi </h3>
        <br>
        <div class="social">
            <ul>
                <li>
                    <a href="#"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png" alt="face"></a>
                </li>
                <li>
                    <a href="#"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png" alt="insta"></a>
                </li>
                <li>
                    <a href="#"><img src="https://img.icons8.com/fluent/48/000000/twitter.png" alt="twi"></a>
                </li>
            </ul>
        </div>
    </div>
    

    </div>
</div>
</section>






<!-- copyright section  -->
<section class="copyright">
    <div class="container text-center">
        <p><h6>Công ty TNHH TBZ STORE Việt Nam Số ĐKKD: 01999999
            <br>
Địa Chỉ: Số 271 Trần Đại Nghĩa, P.Hòa Qúy, Q.Ngũ Hánh Sơn, TP.Đà Nẵng
<br>

Số điện thoại: 0931957248
<br>
Email: lienhepizzatbzstore@gmail.com <a href="#"><b>TBZ STORE</b></a> </h6></p>
     </div>
</section>


<!-- javascript -->
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
	<script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>
	<script src="js/main.js"></script>
	

