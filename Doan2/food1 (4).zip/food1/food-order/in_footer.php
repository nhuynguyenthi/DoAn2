<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <style>
    .tien_de1{
    margin: 50px;
    padding: 0% auto;
}

  .tien_de1 {
    /* text-align: center; */
    color: #008000;
    display: inline;

}
.tien_de{
    text-align: center;
    margin-right:100px;

}
.explore{
    text-align:center;
    color : black;
    border:1px bold green;
    /* background-color:green; */
    font-size:20px;
   


}
.box{
    border:1px bold black;
    background:green;
    padding: 10px;
}

/* #page-header.blog-header{
background-image: url("anh/nen1.jpg");
} */
#blog{
    padding: 150px 150px 0 150px;
}
#blog .blog-box{
    display: flex;
    align-items: center;
    width: 100%;
    position: relative;
}#blog .blog-img{
    width: 50%;
    margin-right: 40px;
}
#blog img{
    width: 100%;
    height: 300px;
    object-fit: cover;
}
#blog .blog-details{
    width: 50%;
   
}
#blog .blog-details a{
    text-decoration: none;
    font-size: 11px;
    color: 	#0000FF;
    font-weight: 700;
    position: relative;
    transition: 0.3s;
}
#blog .blog-details a::after{
    content: " ";
    width: 50px;
    height: 1px;
    background-color: 	#0000FF;
    position: absolute;
    top: 4px;
    right: -60px;
}
#blog .blog-details a:hover{
    color: #ec544e;

}
#blog .blog-details a:hover::after{
    background-color: #088178;
}
#blog .blog-box h1{
    position: absolute;
    top: -40px;
    left: 0;
    font-size: 70px;
    font-weight: 700;
    color: #f6dbf6;
    z-index: -9;
    /* tạo index để cho b+nó ẩn xuống hình  */

}
h4{
    color:green;
}

   </style>
</head>
<body>
<section class="tien_de1">
	<h1 class="tien_de">Hãy cùng chúng tôi khám phá về thức ăn từ chuyên gia </h1>
    <br> <br>
    <div class="box">
    <marquee behavior="" direction="">
    <p class="explore">Hãy đến với cửa hàng ăn uống của chúng tôi bạn sẽ cho bạn "thỏa mãn được vị giác" cùng với nhân viên chuyên nghiệp
	chúng tôi</p>
    <br> 
    <p>
    <mark><span> Chúng tôi cam kết đem những sản phẩm tốt nhất, luôn đổi mới mỗi ngày và đảm bảo chất lượng với dịch vụ tốt nhất đến với mọi người luôn
	an toàn và tiết kiệm thời gian cũng như là chi phí đi lại </span> </mark>
   </p>

    </marquee> 
    </div>
	
   

</section>
<section>
<section id="blog">
        <div class="blog-box">
            <div class="blog-img">
                <img src="images/pizza-blog1.jpg" alt="ảnh chủ đề1">
            </div>
        <div class="blog-details">
            <h4>
                PIZZA PHÔ MAI XÚC XÍCH THƯỢNG HẠNG KIỂU ĐỨC
            </h4>
            <p>
            Pizza Đức được chế biến từ những hương liệu tuyệt vời được làm từ bột mì để có thể làm được một chiếc bánh pizza ngon
             thì người đầu bếp phải lựa chọn bột mì thơm ngon bởi không phải loại bột mì nào cũng thích hợp để làm bánh pizza
             . Bên cạnh đó, thời gian ủ bột, để bột nghỉ, nhào bột cũng cần phải được tuân thủ nghiêm túc nguyên tắc mới
              có thể làm ra bánh pizza ngon .Bên cạnh đó thì để làm pizza kiểu Đức thì không thể thiếu các kiểu xúc xích dùng để làm 
              topping chủ đạo trên chiếc bánh pizza đó cùng với nước sốt pho mai sẽ đem lại hương vị ngon nhất cho người dùng


            </p> 
            <a href="http://localhost/food1/food-order/blog.php">Mời bạn tiếp tục đọc các sản phẩm khác của chúng tôi</a>
        </div>
        <h1>20/11</h1>

        </div>
        <div class="blog-box">
            <div class="blog-img">
                <img src="images/pizza-blog2.jpg" alt="ảnh chủ đề2">
            </div>
        <div class="blog-details">
            <h4>
               PIZZA THƯỢNG HẠNG KIỂU VIỆT 
            </h4>
            <p>
            Việt Nam, để phù hợp với khẩu vị của người Việt thì các món pizza được biến tấu theo nhiều phong cách du nhập từ phương Tây: 
            từ những loại bánh thông thường làm từ thịt thăn, xúc xích, 
            cá ngừ cho đến những loại bảnh hảo hạng được chế biến đặc biệt từ cá hồi xông khói, 
            thịt lợn rừng....trong đó đặc biệt phải kể tới món pizza hải sản gồm có xốt cà và nướng chung với mực và tôm địa phương
            tạo thành những chiếc bánh pizza được phủ lớp sốt đặc biệt tại cửa hàng
    
            </p> 
            <a href="http://localhost/food1/food-order/blog.php">Mời bạn tiếp tục đọc các sản phẩm khác của chúng tôi</a>
        </div>
        

        </div>
        <div class="blog-box">
            <div class="blog-img">
                <img src="images/hamburger-blog3.jpg" alt="ảnh chủ đề3">
            </div>
        <div class="blog-details">
            <h4>
                HAMBURGER KIỂU MĨ
            </h4>
            <p>
                Hamburger kiểu Mĩ được làm và kết hợp với khẩu vị đặc trưng như là thịt được xay hay là thịt bò, 
                kèm thêm một số loại rau như: salad, cà chua và một số gia vị khác phủ lên với sự kết hợp tinh hoa
                đầy hương vị đặc sắc với mùi thơm của bánh mùi thơm của các loại topping đã tạo nên những chiếc bánh 
                Hamburger hảo hạn thơm ngon từ đầu bếp. 
            </p> 
            <a href="http://localhost/food1/food-order/blog.php">Mời bạn tiếp tục đọc các sản phẩm khác của chúng tôi</a>
        </div>
        

        </div><div class="blog-box">
            <div class="blog-img">
                <img src="images/hamburger-blog4.jpg" alt="ảnh chủ đề4">
            </div>
        <div class="blog-details">
            <h4>
                Hamburger kiểu việt 
            </h4>
            <p>
               Hamburger kiểu Việt được chế biến từ những loại bột mì thơm ngon được chọn lọc 
               kèm theo hương vị của chả quế và các loại thịt heo được nướng lên kèm với
               rau xà lách và cà chua mang đậm chất việt kèm theo xốt
               phô mai và majane đậm hương vị chua ngọt thanh 


            </p> 
            <a href="http://localhost/food1/food-order/blog.php">Mời bạn tiếp tục đọc các sản phẩm khác của chúng tôi</a>
        </div>
        

        </div>
        <div class="blog-box">
            <div class="blog-img">
                <img src="images/sandwich-blog5.png" alt="ảnh chủ đề5">
            </div>
        <div class="blog-details">
            <h4>
               Sandwich thịt nướng 
            </h4>
            <p>
            Sandwich 100% Nguyên liệu tươi sạch từ trứng tươi và bơ, tinh bột khoai tây và có hương vị thơm ngon 
            của thịt nướng rau xà lách ,dưa leo tạo nên sự kết hợp hài hòa giữa các gia vị sốt đặc trưng tại 
            của hàng ZBT STORE  
            </p> 
            <a href="#">Mời bạn tiếp tục đọc các sản phẩm khác của chúng tôi</a>
        </div>
        

        </div>
      
        
    </section>
</section>
</body>
</html>