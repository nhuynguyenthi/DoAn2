<?php
ob_start();
include('header.php'); ?>

<?php
	if(isset($_REQUEST['submit'])){
		$name = mysqli_real_escape_string($conn, $_REQUEST['name']);
		$contact = mysqli_real_escape_string($conn, $_REQUEST['contact']);
		$email = mysqli_real_escape_string($conn,$_REQUEST['email'] );
		$address = mysqli_real_escape_string($conn, $_REQUEST['address']);
		date_default_timezone_set('Asia/Dhaka');
		$order_date = date("Y-m-d h:i:sa");
		$status = mysqli_real_escape_string($conn, "Ordered");
		
		if(isset($_COOKIE["shopping_cart"]))
		{
			$cookie_data = stripslashes($_COOKIE['shopping_cart']);
			$cart_data = json_decode($cookie_data, true);
			foreach($cart_data as $keys => $values)
			{
				$total = 0;
				$title = mysqli_real_escape_string($conn, $values["item_name"]);
				$price = mysqli_real_escape_string($conn, $values["item_price"]);
				$qty = mysqli_real_escape_string($conn, $values["item_quantity"]);
				$total = $price * $qty;
				$sql = "INSERT INTO food_order SET
					title = '$title',
					price = $price,
					qty = $qty,
					total = $total,
					order_date = '$order_date',
					status = '$status',
					customer_name = '$name',
					customer_contact = '$contact',
					customer_email = '$email',
					customer_address = '$address'
				";
				$res = mysqli_query($conn, $sql);
			}
			if($res ==  true){
				setcookie("shopping_cart", "", time() - 3600);
				$url= (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
				header("location:cart_core.php?action=order_success&url=$url");
			}
			else{
				$_SESSION['order'] = "<div class='error text-center'>Không thể đặt món ăn.</div>";
			}
		}
		else{
			$_SESSION['order'] = "<div class='error text-center'>Bạn không có thức ăn.</div>";
		}
	}
?>
<!-- food search  -->
<section class="order">
    <div class="container">
        <h2 class="text-center">Điền vào đây để xác nhận đơn đặt hàng của bạn </h2>

        <?php
				if(isset($_SESSION['order'])){
					echo $_SESSION['order'];
					unset($_SESSION['order']);
				}
				if(isset($_SESSION['add_to_cart'])){
					echo $_SESSION['add_to_cart'];
					unset($_SESSION['add_to_cart']);
				}
				
			?>
        <table class="tbl-full" border="0">
            <tr>
                <th>S.N</th>
                <th>Món ăn</th>
                <th>Tên món ăn</th>
                <th>Giá</th>
                <th>Số lượng</th>
                <th>Tổng</th>
                <th>Hoạt động</th>
            </tr>

            <?php
					if(isset($_COOKIE["shopping_cart"]))
					{
						$total = 0;
						$i=1;
						$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
						$cookie_data = stripslashes($_COOKIE['shopping_cart']);
						$cart_data = json_decode($cookie_data, true);
						foreach($cart_data as $keys => $values)
						{
					?>

            <tr>
                <td><?php echo $i++; ?></td>
                <td>
                   <img src="images/food/<?php echo $values["item_img"]; ?>" alt="thức ăn"> 
                </td>
                <td><?php echo $values["item_name"]; ?></td>
							<td><?php echo $values["item_price"]; ?></td>
							<td><?php echo $values["item_quantity"]; ?></td>
							<td><?php echo number_format($values["item_quantity"] * $values["item_price"],0, ',', '.');?></td>
                            <td><a class="btn btn-danger" href="cart_core.php?action=delete&id=<?php echo $values["item_id"]; ?>&food=<?php echo $values["item_name"]; ?>&url=<?php echo $url; ?>">&times;</a></td>
            </tr>

            <?php	
							$total = $total + ($values["item_quantity"] * $values["item_price"]);
							
							
						}
					?>

            <tr>
                <th colspan="5">Tổng</th>
                <th><?php echo number_format($total,0, ',', '.'); ?></th>
							<th></th>
            </tr>
            <?php
					}
					else
					{
						echo '
						<tr>
							<td colspan="7" align="center">Không có mặt hàng trong giỏ hàng</td>
						</tr>
						';
					}
					?>
					  </table>
            <form action="" method="POST" class="order-form">
			  <fieldset>
               <legend>THÔNG TIN THANH TOÁN</legend>
               <div class="order-label">Họ Và Tên</div>
               <input type="text" name="name" placeholder="Nhập tên của bạn" class="input-responsive" class="input-responsive" required>

               <div class="order-label">SĐT</div>
               <input type="tel" name="contact" placeholder="Nhập sđt của bạn" class="input-responsive" class="input-responsive" required>

               <div class="order-label">Email</div>
               <input type="email" name="email" placeholder="Nhập email của bạn" class="input-responsive"class="input-responsive" required>

               <div class="order-label">Địa Chỉ</div>
               <textarea name="address" rows="5" placeholder="Nhập vào địa chỉ" class="input-responsive"class="input-responsive" required></textarea>

               <input type="submit" name="submit" value="Xác nhận đặt món" class="btn btn-primary">
			  </fieldset>
			</form>
</section>


<?php include('footer.php');
      ob_flush();
?>
