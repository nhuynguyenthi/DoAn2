

<?php
	
	include('config.php');
	
	if(isset($_GET['id']) AND isset($_GET['image'])){
		$id = $_GET['id'];
		$image = $_GET['image'];
		if($image != ""){
			$path = "../images/food/".$image;
			$remove = unlink($path);
			if($remove == false){
				$_SESSION['remove'] = "<div class='error text-center'>loại bỏ hình ảnh mặt hàng.</div>";
				header('location:'.SITEURL.'admin/food.php');
				die();
			}
		}
		
		$sql = "DELETE FROM food WHERE id= $id";
		$res = mysqli_query($conn, $sql);
		if($res == true){
			$_SESSION['delete'] = "<div class='success text-center'>Xóa mặt hàng thành công.</div>";
			header('location:'.SITEURL."admin/food.php");
		}
		else{
			$_SESSION['delete'] = "<div class='error text-center'>Đã xóa mặt hàng.</div>";
			header('location:'.SITEURL."admin/food.php");
		}
		
	}
	else{
		header('location:'.SITEURL.'admin/food.php');
	}	
	
	
	
?>
