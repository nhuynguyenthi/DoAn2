

<?php include('header.php'); ?>
   


    <!-- CAtegories Section Starts Here -->
    <section class="" style="padding:5% 0;">
        <div class="container" >
            <h2 class="text-center">Thêm mặt hàng</h2>
			<div class="heading-border"></div>
			
			<?php 
				if(isset($_SESSION['add'])){
					echo $_SESSION['add'];
					echo "<br>";
					unset($_SESSION['add']);
				}
				if(isset($_SESSION['upload'])){
					echo $_SESSION['upload'];
					echo "<br>";
					unset($_SESSION['upload']);
				}
			?>
            
            <form action="" method="POST" enctype="multipart/form-data">
                <table class="tbl-50">

                    <tr>
                        <td>Mặt hàng:</td>
                        <td>
                            <input type="text" name="title" placeholder="Nhập mặt hàng" required>
                        </td>
                    </tr>
                    <tr>
                        <td>Giá:</td>
                        <td>
                            <input type="text" name="price" placeholder="Nhập giá" required>
                        </td>
                    </tr>
                    <tr>
                        <td>Cập nhật ảnh:</td>
                        <td>
                            <input type="file" name="image">
                        </td>
                    </tr>
                    <tr>
                        <td>Mô tả:</td>
                        <td>
							<textarea name="description" cols="30" rows="10" placeholder="Nhập vào mô tả" required></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td>Loại hàng:</td>
                        <td>
                            <select name="category">
								
								<?php 
									$sql="SELECT * FROM category WHERE active='có'";
									$res = mysqli_query($conn, $sql);
									$count = mysqli_num_rows($res);
									if($count>0){
										while($row = mysqli_fetch_assoc($res)){
											$id = $row['id'];
											$title = $row['title'];
											?>
											<option value="<?php echo $id; ?>"><?php echo $title; ?></option>
											<?php
										}
									}
									else{
										?>
										<option value="0">Không tìm thấy danh mục.</option>
										<?php
									}
								?>
							
							</select>
                        </td>
                    </tr>
                    <tr>
                        <td>Sản phẩm nổi bật:</td>
                        <td>
                            <input type="radio" name="featured" value="có"> Có
                            <input type="radio" name="featured" value="không"> Không
                        </td>
                    </tr>
                    <tr>
                        <td>Trạng thái :</td>
                        <td>
                            <input type="radio" name="active" value="có"> Có
                            <input type="radio" name="active" value="không"> Không
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="submit" name="submit" value="Thêm vào mặt hàng" class="btn btn-secondary">
                        </td>
                    </tr>

                </table>
            </form>
            
				
			
            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->

    <?php include('../footer.php'); ?>
    
	<?php
		if(isset($_REQUEST['submit'])){
			$title = mysqli_real_escape_string($conn, $_REQUEST['title']);
			$price = mysqli_real_escape_string($conn, $_REQUEST['price']);
			$description = mysqli_real_escape_string($conn, $_REQUEST['description']);
			$category = mysqli_real_escape_string($conn, $_REQUEST['category']);
			
			if(isset($_REQUEST['featured'])){
				$featured = mysqli_real_escape_string($conn, $_REQUEST['featured']);
			}
			else{
				$featured = "không";
			}
			if(isset($_REQUEST['active'])){
				$active = mysqli_real_escape_string($conn, $_REQUEST['active']);
			}
			else{
				$active = "không";
			}
			if(isset($_FILES['image']['name'])){
				$image = $_FILES['image']['name'];
				
				if($image != ""){
					$file_string = explode(".",$image);
					$ext = end($file_string);
					$image = "food-name-".rand(0000,9999).'.'.$ext;
					
					$source_path = $_FILES['image']['tmp_name'];
					$destination_path = "../images/food/".$image;
					// Upload image
					$upload = move_uploaded_file($source_path, $destination_path);
					if($upload ==  false){
						$_SESSION['upload'] = "<div class='error text-center'>cập nhật mặt hàng.</div>";
						header('location:'.SITEURL.'admin/food-add.php');
						die();
					}
				}
			}
			else{
				$image="";
			}
			$sql2 = "INSERT INTO food SET
				title = '$title',
				price = '$price',
				image = '$image',
				description = '$description',
				category_id = '$category',
				featured = '$featured',
				active = '$active'
			";
			$res2 = mysqli_query($conn, $sql2);
			if($res2 == true){
				$_SESSION['add'] = "<div class='success text-center'>Đã thêm mặt hàng thành công.</div>";
				//header('location:'.SITEURL.'admin/food.php');
				?>
					<script><?php echo("location.href = '".SITEURL."admin/food.php';");?></script>
				<?php
			}
			else{
				$_SESSION['add'] = "<div class='error text-center'>Thêm mặt hàng thất bại.</div>";
				//header('location:'.SITEURL.'admin/food-add.php');
				?>
					<script><?php echo("location.href = '".SITEURL."admin/food-add.php';");?></script>
				<?php
			}
		}
	?>
  
 
