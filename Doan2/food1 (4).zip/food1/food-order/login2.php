<?php
$conn = mysqli_connect ('localhost', 'root', '', 'food') or die ('Không thể kết nối tới database');
mysqli_set_charset($conn, 'UTF8');

// Khởi tạo SESSION
session_start();
if (isset($_SESSION['username'])){
unset($_SESSION['username']);
}

// Dùng Isset kẻm tra
if (isset($_POST['login'])) {

$username = addslashes($_POST['username']);
$password = addslashes($_POST['password']);

if (!$username || !$password) {
echo "Nhập đầy đủ thông tin <a href='javascript: history.go(-1)'>Trở lại</a>";
exit;
}

// mã hóa pasword
$password = md5($password);

//Kiểm tra tên đăng nhập có tồn tại không
$query = "SELECT username, password FROM users WHERE username='$username'";

$result = mysqli_query($conn, $query) or die( mysqli_error($conn));

$row = mysqli_fetch_array($result);

//So sánh 2 mật khẩu có trùng khớp hay không
if ($password != $row['password']) {
echo "Mật khẩu không đúng. Vui lòng nhập lại. <a href='javascript: history.go(-1)'>Trở lại</a>";
exit;
}

//Lưu tên đăng nhập
$_SESSION['username'] = $username;
echo "Xin chào <b>" .$username . "</b>. Bạn đã đăng nhập thành công. <a href=''>Thoát</a>";
die();
$connect->close();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    .wrapper {
    max-width: 500px;
    width: 100%;
    background: #fff;
    margin: 20px auto; /* căn giữa */
    box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.125);
    padding: 30px;
}

.wrapper .title {
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 25px;
    color: green;
    text-transform: uppercase;
    text-align: center;
}

.wrapper .form {
    width: 100%;
}

.wrapper .form .inputfield {
    margin-bottom: 15px;
    display: flex;
    align-items: center;
}

.wrapper .form .inputfield label {
    width: 200px;
    color: #757575;
    margin-right: 10px;
    font-size: 14px;
}

.wrapper .form .inputfield .input {
    width: 100%;
    outline: none;
    border: 1px solid #d5dbd9;
    font-size: 15px;
    padding: 8px 10px;
    border-radius: 3px;
    transition: all 0.3s ease;
}

.wrapper .form .inputfield .input:focus {
    border: 1px solid #ee5057;
}

.wrapper .form .inputfield .button {
    width: 100%;
    padding: 8px 10px;
    font-size: 15px;
    border: 0;
    background:green;
    color: #fff;
    cursor: pointer;
    border-radius: 3px;
    outline: none;
}
</style>
</head>
<body>
<div class="wrapper">
    <div class="title">
        ĐĂNG NHẬP NGƯỜI DÙNG
    </div>
    <form action="<?php ($_SERVER['PHP_SELF'])?>" class="dangnhap" autocomplete="off" method="POST">
        <div class="form">
            <div class="inputfield">
                <label>Tên đăng nhập : </label>
                <input type='text' name='username' />
            </div>
            <div class="inputfield">
                <label>Mật khẩu</label>
                <input type='password' name='password' />
            </div>
            <div class="inputfield">
            <input type='submit' class="button" name="login" value='Đăng nhập' />
            </div>

        </div>
    </form>
</div>
</body>
</html>

